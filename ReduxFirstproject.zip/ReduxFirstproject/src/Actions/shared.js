import API from 'goals-todos-api'


export const RECEIVE_DATA = 'RECEIVE_DATA'

 export function receiveDataAction(todos, goals){
        return{
          type:RECEIVE_DATA,
          todos,
          goals,
        }
      }

export function handleDeleteTodo(todo){
          return(dispatch) => {
            dispatch(removeTodo(todo.id))
          return  API.deleteTodo(todo.id)
                .catch(()=>{
                   dispatch(addTodo(todo))
                   alert('An error occured. Try again ')
                })
          }
      }
export function handleInitialData(){
          return (dispatch) => {
             return Promise.all([
              API.fetchTodos(),
              API.fetchGoals(),
            ]).then(([todos, goals]) => {
             dispatch(receiveDataAction(todos, goals))
           })
          }
        }
