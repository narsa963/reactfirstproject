import React from 'react'
import ReactDOM from 'react-dom'
import * as React from 'react'
import * as ReactDOM from 'react-dom'
import App from './components/App'
import reducer from './reducers'
import middleware from './middleware'
import { Provider } from 'react-redux'
import { createStore } from 'redux'

const store = createStore(reducer, middleware)

ReactDOM.render(
  <React.StrictMode>
  <Provider store={store}>
    <App />
  </React.StrictMode>,
  </Provider>,
  document.getElementById('root')
)
