

{
  type: 'ADD_TODO',
  todo: {
    id : 0,
    name : 'Learn-Redux',
    complete : false,
  }
}
{
  type: 'REMOVE_TODO',
  id:0,
}
{
  type: 'TOGGLE_TODO',
  id:0,
}

{
  type: 'GOAL_TODO',
  goal{
    id:0,
    name = 'Run a Marathon'
  }
}

{
  type:'REMOVE_GOAL',
  id:0,
}

/* characteristic of pure function
1.they are always return the same result if the same arguments passed in
2.they depend only on same arguments passed into them
3 never produse any side effects.
*/
//Reducer function
function todos (state = [], action ){
  switch(action.type) {
    case 'ADD_TODO':
      return state.concat([action.todo])
    case 'REMOVE_TODO':
      return state.filter((todo) => todo.id !== action.id)
    case 'TOGGLE_TODO':
      return state.map((todo) => todo.id !== action.id ? todo :
        object.assign({}, todo, {complete: !todo.complete })
      )
      defalut:
      return state
}
}

 function goals(state = [], action ){
   switch(action.type) {
     case 'GOAL_TODO':
          return state.concat([action.goal])
     case 'REMOVE_GOAL':
          return state.filter((goal) => goal.id !== action.id )
     defalut:
     return state
   }
 }

 function app(state = {}, action){
   return{
     tods:todos(state.todos, action),
     goals:goals(state.goals, action)
   }

 }
/* if (action.type === 'ADD_TODO'){
    return state.concat([action.todo])
  }else if (action.type === 'REMOVE_TODO'){
    return state.filter((todo) => todo.id !== action.id)
  }else if (action.type === 'TOGGLE_TODO'){
    return state.map((todo) => todo.id !== action.id ? todo :
      object.assign({}, todo, {complete: !todo.complete })
    )
  }
  return state

}
*/
function createStore(reducer){
  //the fuction should be four parts
  //1. the state
  //2 get the state(get state)
  //3.listen to the change on the state(subscribe)
  // 4 update the state(dispatch)
let state
let listeners = []
const getState = () => state
const subscribe = (listener) => {
  listeners.push(listener)
  return () => {
    listeners = listenesr.filter((l) => l !==listener)
  }

}
 const dispatch = (action) => {
//call todos
state = reducer (state, action)
// loop over  listener and invoke them
listeners.forEach((listener)=> listener())
 }
   return{
     getState,
     subscribe,
     dispatch,
   }
}
const store = createStore(app)
console.log(a)
store.dispatch ({
  type: 'ADD_TODO',
  todo: {
    id : 0,
    name : 'Learn-Redux',
    complete : false,
  }
})
const store = createStore(todos)
state = reducer(state, action)
//const store = createStore()
//const unsubscribe = store.subscribe(()=>{

//})
//unsubscribe()
